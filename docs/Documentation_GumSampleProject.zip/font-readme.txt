Font is cartoony and listed as 100% free:
http://www.dafont.com/walibi0615.font